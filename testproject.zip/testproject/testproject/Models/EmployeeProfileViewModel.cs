﻿using System.ComponentModel.DataAnnotations;
namespace testproject.Models
{
    public class EmployeeProfileViewModel
    {
        [Required]
        public string EmployeeNumber { get; set; }

        [Required]
        public DateTime HireDate { get; set; }

        [Required]
        public string WorkPhone { get; set; }

        [Required]
        public string PreferredLanguage { get; set; }

        public IFormFile? ProfilePhoto { get; set; }

        public IFormFile? Signature { get; set; }
    }
}
