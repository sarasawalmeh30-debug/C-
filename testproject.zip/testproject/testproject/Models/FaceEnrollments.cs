﻿namespace testproject.Models
{
    public class FaceEnrollments
    {
    }
}
