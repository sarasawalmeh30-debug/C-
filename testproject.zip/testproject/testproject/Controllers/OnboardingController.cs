﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using testproject.Data;
using testproject.Models;

usiusing Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Authorize]
public class OnboardingController : Controller
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly ApplicationDbContext _context;
    private readonly SignInManager<ApplicationUser> _signInManager;

    public OnboardingController(
        UserManager<ApplicationUser> userManager,
        ApplicationDbContext context,
        SignInManager<ApplicationUser> signInManager)
    {
        _userManager = userManager;
        _context = context;
        _signInManager = signInManager;
    }

    // GET: Onboarding/Index
    public async Task<IActionResult> Index()
    {
        var user = await _userManager.GetUserAsync(User);

        if (user == null)
            return RedirectToAction("Login", "Account");

        if (!user.IsActive)
            return Forbid();

        if (user.UserType == "Supplier")
        {
            var supplier = await _context.SupplierProfiles
                .FirstOrDefaultAsync(s => s.UserId == user.Id);

            if (supplier == null || supplier.Status != "Approved")
                return RedirectToAction("Login", "Account");
        }

        if (user.MustChangePassword)
            return RedirectToAction("ChangePassword");

        var nextStep = await GetNextStep(user);

        if (nextStep == "Completed")
            return RedirectToAction("Dashboard", "Home");

        return RedirectToAction(nextStep);
    }

    // GET: Onboarding/ChangePassword
    public IActionResult ChangePassword()
    {
        return View();
    }

    // POST: Onboarding/ChangePassword
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ChangePassword(
        ChangePasswordViewModel model)
    {
        if (!ModelState.IsValid)
            return View(model);

        var user = await _userManager.GetUserAsync(User);

        var result = await _userManager.ChangePasswordAsync(
            user,
            model.CurrentPassword,
            model.NewPassword
        );

        if (result.Succeeded)
        {
            user.MustChangePassword = false;
            user.OnboardingStatus = "InProgress";

            await _userManager.UpdateAsync(user);

            return RedirectToAction("Index");
        }

        foreach (var error in result.Errors)
            ModelState.AddModelError("", error.Description);

        return View(model);
    }

    // GET: Onboarding/Profile
    public async Task<IActionResult> Profile()
    {
        var user = await _userManager.GetUserAsync(User);

        if (user.UserType == "Supplier")
            return RedirectToAction("Index");

        return View();
    }

    // POST: Onboarding/Profile
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Profile(
        EmployeeProfileViewModel model)
    {
        var user = await _userManager.GetUserAsync(User);

        if (user.UserType == "Supplier")
            return Forbid();

        if (!ModelState.IsValid)
            return View(model);

        var profile = await _context.EmployeeProfiles
            .FirstOrDefaultAsync(p => p.UserId == user.Id);

        if (profile == null)
        {
            profile = new EmployeeProfileViewModel
            {
                UserId = user.Id
            };

            _context.EmployeeProfiles.Add(profile);
        }

        profile.EmployeeNumber = model.EmployeeNumber;
        profile.HireDate = model.HireDate;
        profile.WorkPhone = model.WorkPhone;
        profile.PreferredLanguage = model.PreferredLanguage;

        await _context.SaveChangesAsync();

        return RedirectToAction("Index");
    }

    // GET: Onboarding/Fingerprint
    public async Task<IActionResult> Fingerprint()
    {
        var user = await _userManager.GetUserAsync(User);

        var registered = await _context.BiometricCredentials
            .AnyAsync(b => b.UserId == user.Id && !b.IsRevoked);

        if (registered)
            return RedirectToAction("Index");

        return View();
    }

    // GET: Onboarding/Face
    public async Task<IActionResult> Face()
    {
        var user = await _userManager.GetUserAsync(User);

        var registered = await _context.FaceEnrollments
            .AnyAsync(f => f.UserId == user.Id && f.IsActive);

        if (registered)
            return RedirectToAction("Index");

        return View();
    }

    // GET: Onboarding/Consent
    public IActionResult Consent()
    {
        return View();
    }

    // POST: Onboarding/Consent
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Consent(bool accepted)
    {
        if (!accepted)
        {
            ModelState.AddModelError("",
                "You must accept biometric consent.");

            return View();
        }

        var user = await _userManager.GetUserAsync(User);

        user.BiometricConsentAt = DateTime.UtcNow;

        await _userManager.UpdateAsync(user);

        return RedirectToAction("Index");
    }

    // Find the next missing step
    private async Task<string> GetNextStep(ApplicationUser user)
    {
        if (user.MustChangePassword)
            return "ChangePassword";

        if (user.UserType == "Employee")
        {
            var profile = await _context.EmployeeProfiles
                .FirstOrDefaultAsync(p => p.UserId == user.Id);

            if (profile == null)
                return "Profile";
        }

        var fingerprint = await _context.BiometricCredentials
            .AnyAsync(b => b.UserId == user.Id && !b.IsRevoked);

        if (!fingerprint)
            return "Fingerprint";

        var face = await _context.FaceEnrollments
            .AnyAsync(f => f.UserId == user.Id && f.IsActive);

        if (!face)
            return "Face";

        if (user.BiometricConsentAt == null)
            return "Consent";

        return "Completed";
    }
}
